---
name: Support
about: Having trouble with the theme?
title: ""
labels: ""
assignees: ""
---

<!--
  Before opening a new issue please:

  - Verify you have the latest versions of Jekyll and Agency
    installed by running `bundle update`.
  - Search all issues at https://github.com/raviriley/agency-jekyll-theme/issues
    for solutions and to avoid duplication.

  After exhausting these suggestions ask your question below.

  NOTE: Please provide a code repository, gist, code snippet, sample files, or
  screenshots to triage your issue.
-->
